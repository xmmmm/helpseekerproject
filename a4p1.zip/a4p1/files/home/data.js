﻿

setInterval(sticky_menu, 10);

function sticky_menu(){
	var orgPos = $('#navigatorDiv').position();
	// var height = $("#u44").height();
	orgBottom = orgPos.top;
	
	if ($(window).scrollTop() >= (orgBottom)) {
		$("#scroll_menu").css("display","block");
		$("#navigatorDiv li").css("display", "none");
		$("#navigatorDiv").css("box-shadow", "none");
		$("#navigatorDiv").css("-webkit-box-shadow", "none");
		$("#navigatorDiv").css("-moz-box-shadow", "none");
	}else{
		$("#navigatorDiv li").css("display", "block");
		$("#scroll_menu").css("display", "none");
		$("#navigatorDiv").css("box-shadow", "3px 4px 5px #000");
		$("#navigatorDiv").css("-webkit-box-shadow", "3px 4px 5px #000");
		$("#navigatorDiv").css("-moz-box-shadow", "3px 4px 5px #000");
	}
}

